package test.com.smarttask.service;

import com.smarttask.model.Tarea;
import com.smarttask.model.TareaNormal;
import com.smarttask.model.TareaUrgente;
import com.smarttask.service.GestorTareas;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GestorTareasTest {
    private GestorTareas gestor;

    @BeforeEach
    public void setUp() {
        gestor = new GestorTareas();
    }

    @Test
    public void testAgregarTarea() {
        Tarea t1 = new TareaNormal(0, "Estudiar Java");
        Tarea t2 = new TareaUrgente(0, "Entregar proyecto", 2);

        gestor.agregarTarea(t1);
        gestor.agregarTarea(t2);

        assertEquals(1, t1.getId());
        assertEquals(2, t2.getId());
        assertEquals(2, gestor.getTareas().size());
    }

    @Test
    public void testListarTareas() {
        gestor.agregarTarea(new TareaNormal(0, "Comprar pan"));
        gestor.agregarTarea(new TareaUrgente(0, "Pagar cuentas", 1));

        assertDoesNotThrow(() -> gestor.listarTareas());
        assertEquals(2, gestor.getTareas().size());
    }

    @Test
    public void testMarcarComoCompletada() {
        Tarea t1 = new TareaNormal(0, "Hacer ejercicio");
        gestor.agregarTarea(t1);

        assertFalse(t1.isCompletado());
        gestor.marcarComoCompletada(1);
        assertTrue(t1.isCompletado());
    }
}